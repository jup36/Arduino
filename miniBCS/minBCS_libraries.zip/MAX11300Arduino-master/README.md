# MAX11300Arduino
This is a library for talking to the MAX11300 from any Arduino. 

The intent is to provide access to the core functions of the MAX11300 PIXI described in the datasheet (http://datasheets.maximintegrated.com/en/ds/MAX11300.pdf)
The analog switch and level translation functions will be skipped. 

It is part of the Multispork project 
